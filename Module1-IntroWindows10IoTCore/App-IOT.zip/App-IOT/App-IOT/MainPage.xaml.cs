﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices.WindowsRuntime;
using Windows.Foundation;
using Windows.Foundation.Collections;
using Windows.UI.Xaml;
using Windows.UI.Xaml.Controls;
using Windows.UI.Xaml.Controls.Primitives;
using Windows.UI.Xaml.Data;
using Windows.UI.Xaml.Input;
using Windows.UI.Xaml.Media;
using Windows.UI.Xaml.Navigation;
using Windows.Devices.Gpio;
using GHIElectronics.UWP.Shields;

// The Blank Page item template is documented at http://go.microsoft.com/fwlink/?LinkId=402352&clcid=0x409

namespace App_IOT
{
    /// <summary>
    /// An empty page that can be used on its own or navigated to within a Frame.
    /// </summary>
    public sealed partial class MainPage : Page
    {
        private const int LED_PIN = 24;
        private GpioPin Pin { get; set; }
        GHIElectronics.UWP.Shields.FEZHAT fez;
        public MainPage()
        {
            this.InitializeComponent();
            //InitGpio();
            SetupHat();
        }

        private async void SetupHat()
        {
            this.fez = await FEZHAT.CreateAsync();

            var timer = new DispatcherTimer();

            timer.Interval = TimeSpan.FromMilliseconds(50);
            timer.Tick += Timer_Tick;

            timer.Start();
        }

        private void Timer_Tick(object sender, object e)
        {
            if(fez.IsDIO18Pressed())
            {
                tglLED.IsChecked = !tglLED.IsChecked;
            }
        }

        private void InitGpio()
        {
            var ctrl = GpioController.GetDefault();
            if (ctrl != null)
            {
                Pin = ctrl.OpenPin(LED_PIN);
                Pin.SetDriveMode(GpioPinDriveMode.Output);
                Pin.Write(GpioPinValue.Low);
            }
            else
            {
                System.Diagnostics.Debug.WriteLine("no GPIO-Controller");
            }
        }

        private void tglLED_Checked(object sender, RoutedEventArgs e)
        {
            Pin?.Write(GpioPinValue.High);
        }

        private void tglLED_Unchecked(object sender, RoutedEventArgs e)
        {
            Pin?.Write(GpioPinValue.Low);
        }
    }
}
